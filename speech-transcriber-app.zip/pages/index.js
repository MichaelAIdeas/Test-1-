import dynamic from "next/dynamic";

const OpinionFactAnalyzer = dynamic(() => import("../src/OpinionFactAnalyzer"), {
  ssr: false,
});

export default function Home() {
  return <OpinionFactAnalyzer />;
}
