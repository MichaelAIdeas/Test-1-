import { useState, useRef } from "react";
import WaveSurfer from "wavesurfer.js";

export default function OpinionFactAnalyzer() {
  const [recording, setRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [audioUrl, setAudioUrl] = useState(null);
  const wavesurferRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;
    chunksRef.current = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        chunksRef.current.push(e.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
      initWaveform(url);
      fakeTranscribe();
    };

    mediaRecorder.start();
    setRecording(true);
  };

  const stopRecording = () => {
    mediaRecorderRef.current.stop();
    setRecording(false);
  };

  const initWaveform = (url) => {
    if (wavesurferRef.current) {
      wavesurferRef.current.destroy();
    }
    wavesurferRef.current = WaveSurfer.create({
      container: "#waveform",
      waveColor: "#ccc",
      progressColor: "#4f46e5",
      cursorColor: "#111",
      height: 80,
    });
    wavesurferRef.current.load(url);
  };

  const fakeTranscribe = () => {
    // Placeholder for Whisper API call
    setTranscript("This is a placeholder transcript (replace with Whisper API).");
  };

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif" }}>
      <h1>Speech Transcriber App</h1>
      {!recording && (
        <button onClick={startRecording} style={{ marginRight: 10 }}>
          🎙️ Start Recording
        </button>
      )}
      {recording && (
        <button onClick={stopRecording} style={{ marginRight: 10 }}>
          ⏹️ Stop Recording
        </button>
      )}

      <div id="waveform" style={{ marginTop: 20 }}></div>

      {transcript && (
        <div style={{ marginTop: 20 }}>
          <h2>Transcript</h2>
          <p>{transcript}</p>
        </div>
      )}
    </div>
  );
}
