# Speech Transcriber App

## Run Locally on Replit
1. Import this repo into Replit or upload the zip file.
2. Run `npm install` once.
3. Press **Run** → it will start at port 3000.
4. Open in external browser if Webview fails.

## Features
- Record audio from your microphone.
- Scrub through waveform with WaveSurfer.js.
- Placeholder transcription (connect Whisper API for real results).
